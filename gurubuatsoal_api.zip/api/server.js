// server.js
// Aplikasi Express.js yang mengimplementasikan REST API untuk kelas dan tugas

const express = require('express'); // Mengimpor Express.js
const cors = require('cors');     // Mengimpor middleware CORS
const db = require('./db');       // Mengimpor modul koneksi database

const app = express();           // Membuat instance aplikasi Express
const PORT = process.env.PORT || 3000; // Port server, default 3000

// Middleware
app.use(cors()); // Mengaktifkan CORS agar frontend dapat mengakses API
app.use(express.json()); // Mengizinkan Express untuk mengurai body request sebagai JSON

// Endpoint untuk Model.php::getdaftarclass()
// Mengembalikan daftar kelas yang hardcode (sesuai Model.php asli)
app.get('/api/classes', (req, res) => {
    // Fungsi getdaftarclass dari Model.php mengembalikan array hardcode
    const classes = ['class 1', 'class 2', 'class 3', 'class 4'];
    res.status(200).json(classes);
});

// Endpoint untuk Model.php::getClassDetail($className)
// Mengembalikan detail kelas hardcode berdasarkan nama kelas (sesuai Model.php asli)
app.get('/api/class/:className', (req, res) => {
    const { className } = req.params; // Mengambil nama kelas dari parameter URL

    // Data hardcode yang sesuai dengan getClassDetail di Model.php
    const data = {
        'class 1': {
            id: 1,
            name: 'class 1',
            siswa: [''], // 'siswa' kosong di model asli
            tugas: [
                { id: 1, judul: 'Tugas Matematika' },
                { id: 2, judul: 'Tugas IPA' }
            ]
        },
        'class 2': {
            id: 2,
            name: 'class 2',
            siswa: [''], // 'siswa' kosong di model asli
            tugas: [
                { id: 1, judul: 'Tugas Bahasa Indonesia' }
            ]
        }
    };

    const classDetail = data[className]; // Mencari detail kelas

    if (classDetail) {
        res.status(200).json(classDetail); // Mengembalikan detail kelas jika ditemukan
    } else {
        res.status(404).json({ message: 'Kelas tidak ditemukan.' }); // Mengembalikan 404 jika tidak ditemukan
    }
});

// *************** TAMBAHAN ENDPOINT BARU UNTUK DEMO DATABASE CLASSES LIST ***************
// Endpoint untuk mendapatkan daftar semua kelas dari database
app.get('/api/db/class-list', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();
        const [rows] = await connection.execute("SELECT id, nama FROM kelas");
        res.status(200).json(rows);
    } catch (error) {
        console.error('Error fetching database class list:', error);
        res.status(500).json({ message: 'Terjadi kesalahan server saat mengambil daftar kelas dari database.', error: error.message });
    } finally {
        if (connection) connection.release();
    }
});
// **************************************************************************************


// Endpoint untuk modelgabungan.php::modelclass($id)
// Mengembalikan detail kelas, anggota, dan tugas dari database
app.get('/api/db/class/:id', async (req, res) => {
    const { id } = req.params; // Mengambil ID kelas dari parameter URL
    let connection; // Variabel untuk koneksi database

    try {
        connection = await db.getConnection(); // Mendapatkan koneksi dari pool
        await connection.beginTransaction(); // Memulai transaksi

        // 1. Ambil detail kelas
        const [kelasRows] = await connection.execute(
            "SELECT id, nama FROM kelas WHERE id = ?",
            [id]
        );
        const kelas = kelasRows[0]; // Ambil baris pertama (detail kelas)

        if (!kelas) {
            await connection.rollback(); // Rollback transaksi jika kelas tidak ditemukan
            return res.status(404).json({ message: 'Kelas tidak ditemukan.' });
        }

        // 2. Ambil anggota (siswa) berdasarkan kelas_id
        const [anggotaRows] = await connection.execute(
            "SELECT nama FROM anggota WHERE kelas_id = ?",
            [id]
        );
        // Map hasil query menjadi array nama siswa
        const anggota = anggotaRows.map(row => row.nama); 

        // 3. Ambil tugas berdasarkan kelas_id
        const [tugasRows] = await connection.execute(
            "SELECT id, judul FROM tugas FROM tugas WHERE kelas_id = ?", // Corrected table name
            [id]
        );
        const tugas = tugasRows; // Hasil query tugas

        // Bentuk respons sesuai dengan output modelclass di PHP
        const result = {
            id: kelas.id,
            name: kelas.nama,
            members: anggota, // Anggota yang sudah difetch dengan benar
            tugas: tugas
        };

        await connection.commit(); // Commit transaksi jika semua berhasil
        res.status(200).json(result); // Mengembalikan data
    } catch (error) {
        if (connection) await connection.rollback(); // Rollback jika ada error
        console.error('Error in modelclass API:', error); // Log error
        res.status(500).json({ message: 'Terjadi kesalahan server.', error: error.message });
    } finally {
        if (connection) connection.release(); // Pastikan koneksi dilepaskan kembali ke pool
    }
});

// Endpoint untuk modelgabungan.php::Coso($tugasId)
// Mengembalikan detail tugas dari database
app.get('/api/db/task/:id', async (req, res) => {
    const { id } = req.params; // Mengambil ID tugas dari parameter URL
    let connection; // Variabel untuk koneksi database

    try {
        connection = await db.getConnection(); // Mendapatkan koneksi dari pool
        
        // Ambil detail tugas berdasarkan ID
        const [tugasRows] = await connection.execute(
            "SELECT id, judul, soal, kelas_id FROM tugas WHERE id = ?",
            [id]
        );
        const tugas = tugasRows[0]; // Ambil baris pertama (detail tugas)

        if (tugas) {
            res.status(200).json(tugas); // Mengembalikan detail tugas jika ditemukan
        } else {
            res.status(404).json({ message: 'Tugas tidak ditemukan.' }); // Mengembalikan 404 jika tidak ditemukan
        }
    } catch (error) {
        console.error('Error in Coso API:', error); // Log error
        res.status(500).json({ message: 'Terjadi kesalahan server.', error: error.message });
    } finally {
        if (connection) connection.release(); // Pastikan koneksi dilepaskan kembali ke pool
    }
});

// Menjalankan server
app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
});
